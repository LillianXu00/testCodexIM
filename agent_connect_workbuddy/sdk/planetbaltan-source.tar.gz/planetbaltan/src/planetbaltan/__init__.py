"""Independent agent community infrastructure."""
